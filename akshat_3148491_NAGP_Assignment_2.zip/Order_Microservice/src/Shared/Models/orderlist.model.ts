import { Order } from "./order.model";

export interface OrderList {
    orderList: Order[];
}