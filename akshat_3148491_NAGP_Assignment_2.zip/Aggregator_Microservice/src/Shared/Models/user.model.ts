export interface User {
    name: string,
    id: string,
    age: number,
    username: string,
    role: string
}