import { User } from "./user.model";

export interface UserList {
    userList: User[];
}