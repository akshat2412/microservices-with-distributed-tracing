export interface User {
    name: string,
    id: string,
    age: number,
    userName: string,
    role: string,
    password: string
}