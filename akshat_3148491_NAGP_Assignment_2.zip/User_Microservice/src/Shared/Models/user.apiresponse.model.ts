export interface UserApiResponse {
    name: string,
    id: string,
    age: number,
    userName: string,
    role: string
}